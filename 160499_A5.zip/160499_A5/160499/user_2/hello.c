#include<stdio.h>

void microkernel_sendmsg(char *);

int main(){
	printf("Helloworld!\n");
	printf("This must be a monolithic design\n");
	microkernel_sendmsg("is more portable");
	printf("This is a newline\n");
	return 0;
}

void microkernel_sendmsg(char *a){
	printf("microkernel: %s\n", a);
}
