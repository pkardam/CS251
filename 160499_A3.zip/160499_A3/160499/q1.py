import numpy as np
import re
import sys

def lead_zero(s):
	ff=0;a="";b="";
	k = 1 if s[0]=='-' else 0;
	for i in range(k,len(s)):
		a=a+s[i];
	k=1 if s.find(".")!=-1 else 0;
	for i in range(k*len(a)-1,-1*k,-1):
		if ff==0 and a[i]=='0':
			continue;
		else:
			ff=1;b=a[i]+b;
	b= a if(k==0) else b;
	return b;

def getbase(base):
    b=0;p=1;
    for j in range(len(base)-1,-1,-1):
    	b+=(ord(base[j])-ord('0'))*p;p*=10;
    return (b,base)

def check(b,s):
	if b<2 or b>36:
		return False
	for j in range(0,len(s)):
		if s[j]=='.':
			continue;
		elif s[j]<='z' and s[j]>='a':
			if (ord(s[j])-ord('a')+10)>=b:
				return False;
		elif s[j]<='Z' and s[j]>='A':
			if (ord(s[j])-ord('A')+10)>=b:
				return False;
		else:
			if (ord(s[j])-ord('0'))>=b:
				return False;
	return True;

s = "...";base="..."

#regex
reg = "-?[0-9A-Za-z]+\.?[0-9A-Za-z]*$|-?[0-9A-Za-z]*\.?[0-9A-Za-z]+$"
reg2 = "[0-9]+$"

#number
s=sys.argv[1];
i = 1 if s[0]=='-' else 0;
s=lead_zero(s);

if not re.match(reg,s):
	print "invalid number!";quit();

#base
b,base=getbase(sys.argv[2]);
base = base if check(b,s) else "..";

if not re.match(reg2,base):
	print "invalid base!";quit();
#conversion
n=0;p=1;d=0;
for j in range(len(s)-1,-1,-1):
	if s[j]=='.':
		d=len(s)-1-j;
		continue;
	elif s[j]<='z' and s[j]>='a':
		n+=(ord(s[j])-ord('a')+10)*p
	elif s[j]<='Z' and s[j]>='A':
		n+=(ord(s[j])-ord('A')+10)*p
	else:
		n+=(ord(s[j])-ord('0'))*p;
	p*=b

n/=1.0*b**d
n*= -1.0 if i==1 else 1.0;
print('%9.9f'%n)
