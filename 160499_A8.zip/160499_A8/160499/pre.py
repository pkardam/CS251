import subprocess as sub

f=open("params.txt","r");
par=f.read();
f.close();

f=open("threads.txt","r");
thread=f.read();
f.close();

if thread[-1]=="\n":
    thread=thread[:-1];
thread=thread.split(" ");

if par[-1]=="\n":
    par=par[:-1];
par=par.split(" ");

f=open("output.log","w");

ite=100;

for p in par:
    for th in thread:
        for i in range(0,ite):
            output = sub.Popen(['./app.ex1',p,th],stdout=sub.PIPE,stderr=sub.PIPE)
            time, errors = output.communicate()
            time=time.split(" ")[3];
            f.write("%s %s %s\n"% (p,th,time));
