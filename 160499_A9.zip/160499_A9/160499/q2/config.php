<?php

$host       = "127.0.0.1";
$db_user = new SQLite3('user.db');
$db_bank = new SQLite3('bank.db');
$db_admin = new SQLite3('admin.db');
$username   = "root";
$password   = "";
$dbname     = "data";
$dsn        = "mysql:host=$host;dbname=$dbname";
