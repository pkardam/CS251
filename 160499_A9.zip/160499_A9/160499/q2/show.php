<?php require "install.php" ?>

<!doctype html>
<html lang="en">

<head>
	<title>LBS: Database</title>
	<link rel="stylesheet" href="css/style.css">
</head>

<body>
	<h1>Let's Build Stuff</h1>

<?php
  function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }

    $_POST['user']= test_input($_POST['user']);
    $_POST['password']=test_input($_POST['password']);

    $user=$_POST['user'];
    $password=$_POST['password'];

    $exists = sprintf(
        'SELECT COUNT(*) FROM %s WHERE user = "%s" AND password = "%s";',
        "admin", $user, $password
    );
		$result = $db_admin->query($exists);
		$row=$result->fetchArray();


    if($row[0]==0){
       ?>
       <blockquote>Incorrect username or password.</blockquote> <?php
    }
    else{
        require "config.php";
        require "common.php";

        $sql = "SELECT * FROM users";
				$result = $db_user->query($sql);
				?>
				<table>
  				<thead>
  					<tr>
  						<th>Name</th>
  						<th>Address</th>
  						<th>Email Address</th>
  						<th>Mobile</th>
  						<th>Account</th>
  					</tr>
  				</thead>
  				<tbody>
						<?php
				while ($row = $result->fetchArray()) {
					?>
					<tr>
  					<td><?php echo $row[0]; ?></td>
  					<td><?php echo $row[1]; ?></td>
  					<td><?php echo $row[2]; ?></td>
  					<td><?php echo $row[3]; ?></td>
						<td><?php echo $row[4]; ?></td>
  				</tr>
					<?php
				}
				?>
				</tbody>
				</table>
  		<?php }
?>

<a href="/read.php">All Registrations</a><br>
<a href="/index.php">Another Registration</a>
</body>
</html>
