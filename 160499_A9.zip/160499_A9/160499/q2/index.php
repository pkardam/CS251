<!doctype html>
<html lang="en">

<head>
	<title>LBS: Add user</title>

	<link rel="stylesheet" href="/public/css/style.css">
	<script>
		function test_input($data) {
			$data = trim($data);
			$data = stripslashes($data);
			$data = htmlspecialchars($data);
			return $data;
		}
		function check(post){
			post.name=test_input(post.name);
			post.email=test_input(post.email);
			post.address=test_input(post.address);
			post.account=test_input(post.account);
			post.mobile=test_input(post.mobile);
			post.password=test_input(post.password);

	    var english = /^[a-zA-Z ]+$/;
			var email=/^[a-zA-Z]+[@].+[.]com$/;
			if(english.test(post.name.value) == false) {
				alert("Name must be in alphabets only");
				post.name.focus();
				return false;
			}
			if(post.name.value.length > 20){
				alert("Name Field should be smaller than 20 characters.");
				post.name.focus();
				return false;
			}

			if(post.address.value.length > 100){
				alert("Name Field should be smaller than 100 characters.");
				post.name.focus();
				return false;
			}

			if(email.test(post.email.value) == false) {
				alert("email must be in .com only");
				post.name.focus();
				return false;
			}

	    return true;
	  }
	</script>
	<?php include "install.php";?>

</head>

<body>
	<h1>Let's Build Stuff</h1>

<?php
if (isset($_POST['submit']) && $statement){ ?>
	<blockquote><?php echo $_POST['name']; ?> successfully registered.</blockquote>
<?php
} ?>

<h2>Add a user</h2>

<form method="post" onSubmit="return check(this);" action="../verify.php" >
<label for="name">Name</label>
<input type="text" name="name" id="name" size="20" required>

<label for="address">Address</label>
<input type="text" name="address" id="address" required>

<label for="email">Email Address</label>
<input type="email" name="email" id="email" required>

<label for="mobile">Mobile</label>
<input type="number" name="mobile" id="mobile" min="1000000000" max="9999999999" required>

<label for="account">Account</label>
<input type="number" name="account" id="account" min="10000" max="99999" required>

<label for="password">Password</label>
<input type="password" name="password" id="password" required>

<input type="submit" name="submit" id="submit">
</form>

<a href="/read.php">View all registrations</a>

</body>
</html>
