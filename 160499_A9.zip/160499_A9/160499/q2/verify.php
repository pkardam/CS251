<?php require "install.php" ?>

<!doctype html>
<html lang="en">
<head>
	<title>Let's Build Stuff</title>
	<link rel="stylesheet" href="/public/css/style.css">
</head>

<body>
	<h1>LBS: Detail</h1>

<?php
  function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
  require "config.php";
	require "common.php";

  $_POST['name']= test_input($_POST['name']);
  $_POST['email']=test_input($_POST['email']);
  $_POST['address']=test_input($_POST['address']);
  $_POST['account']=test_input($_POST['account']);
  $_POST['mobile']=test_input($_POST['mobile']);
  $_POST['password']=test_input($_POST['password']);

	$new_user = array(
		"name" => $_POST['name'],
		"address"  => $_POST['address'],
		"email"     => $_POST['email'],
		"mobile"       => $_POST['mobile'],
		"account"  => $_POST['account'],
		"password"  => $_POST['password']
	);

  $email=$_POST['email'];
  $exists = sprintf(
      'SELECT COUNT(*) FROM %s WHERE email = "%s";',
      "users", $email
  );
	$result = $db_user->query($exists);
	$row=$result->fetchArray();

	if($row[0]!=0){
     echo "<h4>User already registered.</h4>";
  }
  else{
    //check balance
    $account=$_POST['account'];
    $sql = sprintf('SELECT COUNT(*) FROM bank WHERE account = %s AND balance >= 1000;',
     		$account);
		$result = $db_bank->query($sql);
		$row=$result->fetchArray();

    $sql = sprintf('SELECT COUNT(*) FROM bank WHERE account = %s;',
						$account);

		$there = $db_bank->query($sql);
		$row2=$there->fetchArray();

    if($row2[0]==0){
       echo "<h4>Invalid account number.</h4>";
    }
    else if($row[0]==0){
				echo $row[0] . "," . $row[1] . "<br>";
        echo "<h4>Not enough balance.</h4>";
    }
    else{
      //check if password match
      $password=$_POST['password'];
      $account =$_POST['account'];

      $sql = sprintf(
          'SELECT * FROM %s WHERE account = "%s";',
          "bank", $account
      );
			$result = $db_bank->query($sql);
			$row=$result->fetchArray();

      if($row[1]!=$password){
        echo "<h4>Incorrect password.</h4>";
      }
      else{
        $sql = sprintf(
            'INSERT INTO %s VALUES ("%s","%s","%s",%s,%s,"%s");',
            "users",  $_POST['name'], $_POST['address'], $_POST['email'], $_POST['mobile'], $_POST['account'], $_POST['password']
					);
				$statement = $db_user->query($sql);

        $account=$_POST['account'];
        $sql = sprintf(
            'UPDATE %s SET balance= balance-1000 WHERE account = "%s";',
            "bank",$account
        );
				$update = $db_bank->query($sql);
        echo "<h4>Record UPDATED successfully, id:" . $account . ", email:" . $new_user["email"] . "</h4>";
      }
    }
  }

  if (isset($_POST['submit']) && $statement){
  	echo "<h4>" . $_POST['name'] . " successfully registered." . "</h4>";
  }
?>

<a href="/index.php">Another Registration</a>
</body>
</html>
