<?php require "config.php";

$db_user = new SQLite3('user.db');
$sql = "CREATE TABLE IF NOT EXISTS users (
	name VARCHAR(20) NOT NULL,
	address VARCHAR(100) NOT NULL,
	email VARCHAR(50) NOT NULL PRIMARY KEY,
	mobile INT(10) NOT NULL,
	account INT(5) NOT NULL,
	password VARCHAR(20) NOT NULL
);";
$insres = $db_user->query($sql);

$db_bank = new SQLite3('bank.db');
$sql="CREATE TABLE IF NOT EXISTS bank (
	account INT(5) NOT NULL,
	password VARCHAR(20) NOT NULL,
	balance INT(20) NOT NULL
);
";
$insres = $db_bank->query($sql);


$db_admin = new SQLite3('admin.db');
$sql="CREATE TABLE IF NOT EXISTS admin (
	user VARCHAR(10) NOT NULL,
	password VARCHAR(20) NOT NULL
);";
$insres = $db_admin->query($sql);

// $sql='INSERT INTO admin VALUES ("root","abc");';
// $insres = $db_admin->query($sql);
//
// $sql='INSERT INTO bank VALUES (10000,"abc",3333);';
// $insres = $db_bank->query($sql);
// $sql='INSERT INTO bank VALUES (10001,"abc",900);';
// $insres = $db_bank->query($sql);
// $sql='INSERT INTO bank VALUES (10002,"abc",33333300303);';
// $insres = $db_bank->query($sql);
// $sql='INSERT INTO bank VALUES (10003,"abc",1000);';
// $insres = $db_bank->query($sql);


echo "Database and table users ready for use.";
