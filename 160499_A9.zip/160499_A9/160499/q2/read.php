<!doctype html>
<html lang="en">

<head>
	<title>LBS: All Registrations</title>
	<link rel="stylesheet" href="css/style.css">
	<script>
		function test_input($data) {
			$data = trim($data);
			$data = stripslashes($data);
			$data = htmlspecialchars($data);
			return $data;
		}
	</script>
</head>

<body>
	<h1>Let's Build Stuff</h1>

<h2>Find user based on Account</h2>

<form method="post" action="show.php">
	<label for="user">User Name</label>
	<input type="text" id="user" name="user">
	<label for="password">Password</label>
	<input type="password" id="password" name="password">
	<input type="submit" name="submit" value="View Results" >
</form>

<a href="/index.php">Another Registration</a>

</body>
</html>
